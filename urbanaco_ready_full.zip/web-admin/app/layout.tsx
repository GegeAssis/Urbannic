import './globals.css'; export default function Root({children}:{children:React.ReactNode}){return(<html lang='pt-br'><body><main className='max-w-6xl mx-auto p-4'>{children}</main></body></html>)}
